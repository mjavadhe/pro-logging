# __init__.py

from .logger import AdvancedLogger

# Make the AdvancedLogger class accessible when importing the package
__all__ = ["AdvancedLogger"]
